

<?php $__env->startSection('content'); ?>
<div class="container-xl">
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Nuevo Horario de atencion</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <?php echo Form::open(['route' => 'horarios.store', 'method' => 'POST']); ?>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <?php echo Form::label('Dia', 'Dia'); ?>

                                        <?php echo Form::text('Dia', null, ['class' => 'form-control']); ?>

                                    </div>
        
                        
                                    <div class="form-group">
                                        <?php echo Form::label('mañana', 'Mañana'); ?>

                                        <?php echo Form::text('mañana', null, ['class' => 'form-control']); ?>

                                    </div>
                                    <div class="form-group">
                                        <?php echo Form::label('tarde', 'Tarde'); ?>

                                        <?php echo Form::text('tarde', null, ['class' => 'form-control']); ?>

                                    </div>
                                    <div class="form-group">
                                        <?php echo Form::label('noche', 'Noche'); ?>

                                        <?php echo Form::text('noche', null, ['class' => 'form-control']); ?>

                                        
                                    </div>
                            
                
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Guardar</button>
                                <a href="<?php echo e(route('personal.index')); ?>" class="btn btn-danger">Cancelar</a>
                            </div>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.tabler-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\erp\resources\views/horarios/crear.blade.php ENDPATH**/ ?>