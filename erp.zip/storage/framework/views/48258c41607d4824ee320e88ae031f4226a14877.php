<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Nuevo Turno</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <?php echo Form::open(['route' => 'turno.store', 'method' => 'POST']); ?>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <?php echo Form::label('descripcion', 'Descripcion'); ?>

                                        <?php echo Form::text('descripcion', null, ['class' => 'form-control']); ?>

                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="horaInicio">Ingrese la hora de Inicio</label>
                                        <input type="time" name="horaInicio" class="form-control"
                                            value="<?php echo e(old('horaInicio')); ?>" autocomplete="off" placeholder="07:00" required>
                                        <?php $__errorArgs = ['horaInicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small>*<?php echo e($message); ?></small>
                                            <br><br>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="horaFin">Ingrese la hora Final</label>
                                        <input type="time" name="horaFin" class="form-control"
                                            value="<?php echo e(old('horaFin')); ?>" autocomplete="off" placeholder="13:00" required>
                                        <?php $__errorArgs = ['horaFin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small>*<?php echo e($message); ?></small>
                                            <br><br>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Guardar</button>
                                <a href="<?php echo e(route('personal.index')); ?>" class="btn btn-danger">Cancelar</a>
                            </div>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp-master\resources\views/turno/crear.blade.php ENDPATH**/ ?>