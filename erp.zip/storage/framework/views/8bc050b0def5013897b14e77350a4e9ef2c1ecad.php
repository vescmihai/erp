<div class="footer-left">
    All rights reserved &copy; <?php echo e(date('Y')); ?>

</div>
<?php /**PATH C:\xampp\htdocs\Laravel8\resources\views/layouts/footer.blade.php ENDPATH**/ ?>