<div class="footer-left">
    All rights reserved &copy; <?php echo e(date('Y')); ?>

</div>
<?php /**PATH C:\laragon\www\erp\resources\views/layouts/footer.blade.php ENDPATH**/ ?>