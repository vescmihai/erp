<?php $__env->startSection('content'); ?>
<div class="container-xl">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span id="card_title">
                                <?php echo e(__('Gestionar bitácora')); ?>

                            </span>
                        </div>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                
                                <div class="form-group">
                                    <form action="<?php echo e(route('bitacora.index')); ?>" method="GET" role="search">

                                        <div class="input-group">
                                            <input type="text" class="form-control mr-2" name="term" placeholder="Buscar fecha" id="term">
                                                <a href="<?php echo e(route('bitacora.index')); ?>" class=" mt-1">
                                                    <span class="input-group-btn">
                                                        <button class="btn btn-primary" type="submit" title="Buscar fecha">
                                                            <span class="fas fa-search"></span>
                                                        </button>

                                                        <button class="btn btn-success" type="button" title="Reiniciar">
                                                            <span class="fas fa-sync-alt"></span>
                                                        </button>
                                                    </span>
                                                </a>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                                <thead class="thead">
                                    
                                    <tr>
                                        <th scope="col">Nº</th>
                                        <th scope="col">Usuario</th>
                                        <th scope="col">Apartado</th>
                                        <th scope="col">Acción</th>
                                        <th scope="col">Columna</th>
                                        <th scope="col">Fecha</th> 

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($actividad->id); ?></td>
                                        <td><?php echo e($actividad->name); ?></td>
                                        <td><?php echo e($actividad->log_name); ?></td>
                                        <td><?php echo e($actividad->description); ?></td>
                                        <td><?php echo e($actividad->subject_id); ?></td>
                                        <td><?php echo e($actividad->created_at); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.tabler-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\erp\resources\views/bitacora/index.blade.php ENDPATH**/ ?>