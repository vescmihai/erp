

<?php $__env->startSection('content'); ?>
<div class="container-xl">
<section class="section">
  <div class="section-header">
      <h3 class="page__heading">Personal</h3>
  </div>
      <div class="section-body">
          <div class="row">
              <div class="col-lg-12">
                  <div class="card">
                      <div class="card-body">                           
                          <a class="btn btn-dark" href="<?php echo e(route('personal.create')); ?>">Nuevo</a>        
                         
                            <table class="table table-striped mt-2">
                              <thead style="background-color:#6777ef">                                     
                                  <th style="display: none;">ID</th>
                                  <th style=>Nombre</th>
                                  <th style=>Apellido Paterno</th>
                                  <th style=>Apellido Materno</th>
                                  <th style=>Sexo</th>
                                  <th style=>Edad</th>
                                  <th style=>Dirección</th>
                                  <th style=>Estado</th>
                                  <th style=>Tipo</th>
                                  <th style=>Acciones</th>                                                                   
                              </thead>
                              <tbody>
                                <?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                    <td style="display: none;"><?php echo e($persona->id); ?></td>
                                    <td><?php echo e($persona->nombre); ?></td>
                                    <td><?php echo e($persona->apellidoPaterno); ?></td>
                                    <td><?php echo e($persona->apellidoMaterno); ?></td>
                                    <td><?php echo e($persona->sexo); ?></td>
                                    <td><?php echo e($persona->edad); ?></td>
                                    <td><?php echo e($persona->direccion); ?></td>
                                    <td><?php echo e($persona->estado); ?></td>
                                    <td><?php echo e($persona->tipo); ?></td>
                                    <td>                                  
                                      <a class="btn btn-primary" href="<?php echo e(route('personal.edit',$persona->id)); ?>">Editar</a>
                                      <a class="btn btn-success" href="<?php echo e(route('personal.pdf',$persona->id)); ?>">Descargar</a>
                                      <?php echo Form::open(['method' => 'DELETE','route' => ['personal.destroy', $persona->id],'style'=>'display:inline']); ?>

                                          <?php echo Form::submit('Borrar', ['class' => 'btn btn-danger']); ?>

                                      <?php echo Form::close(); ?>

                                    </td>
                                  </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                            </table>
                            <!-- Centramos la paginacion a la derecha -->
                          <div class="pagination justify-content-end">
                            <?php echo $personal->links(); ?>

                          </div>     
                            
                      </div>
                  </div>
              </div>
          </div>
      </div>
    </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.tabler-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\erp\resources\views/personal/index.blade.php ENDPATH**/ ?>