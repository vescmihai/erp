

<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="section-header">
    <h3 class="page__heading">Nuevo Personal</h3>
  </div>
  <div class="section-body">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <?php echo Form::open(['route' => 'personal.store', 'method' => 'POST']); ?>

            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <?php echo Form::label('nombre', 'Nombre'); ?>

                  <?php echo Form::text('nombre', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('apellidoPaterno', 'Apellido Paterno'); ?>

                  <?php echo Form::text('apellidoPaterno', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('apellidoMaterno', 'Apellido Materno'); ?>

                  <?php echo Form::text('apellidoMaterno', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('sexo', 'Sexo'); ?>

                  <?php echo Form::select('sexo', ['M' => 'Masculino', 'F' => 'Femenino'], null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('edad', 'Edad'); ?>

                  <?php echo Form::number('edad', null, ['class' => 'form-control']); ?>

                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <?php echo Form::label('fechaNac', 'Fecha de Nacimiento'); ?>

                  <?php echo Form::date('fechaNac', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('telefono', 'Teléfono'); ?>

                  <?php echo Form::number('telefono', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('direccion', 'Dirección'); ?>

                  <?php echo Form::text('direccion', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('estado', 'Estado'); ?>

                  <?php echo Form::text('estado', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('tipo', 'Tipo'); ?>

                  <?php echo Form::text('tipo', null, ['class' => 'form-control']); ?>

                </div>
              </div>
            </div>
            <div class="form-group">
              <button type="submit" class="btn btn-primary">Guardar</button>
              <a href="<?php echo e(route('personal.index')); ?>" class="btn btn-danger">Cancelar</a>
            </div>
            <?php echo Form::close(); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erp\resources\views/personal/crear.blade.php ENDPATH**/ ?>