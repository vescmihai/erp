

<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="section-header">
      <h3 class="page__heading">Personal</h3>
  </div>
      <div class="section-body">
          <div class="row">
              <div class="col-lg-12">
                  <div class="card">
                      <div class="card-body">                           
                          <a class="btn btn-dark" href="<?php echo e(route('personal.create')); ?>">Nuevo</a>        
                         
                            <table class="table table-striped mt-2">
                              <thead style="background-color:#6777ef">                                     
                                  <th style="display: none;">ID</th>
                                  <th style="color:#fff;">Nombre</th>
                                  <th style="color:#fff;">Apellido Paterno</th>
                                  <th style="color:#fff;">Apellido Materno</th>
                                  <th style="color:#fff;">Sexo</th>
                                  <th style="color:#fff;">Edad</th>
                                  <th style="color:#fff;">Dirección</th>
                                  <th style="color:#fff;">Estado</th>
                                  <th style="color:#fff;">Tipo</th>
                                  <th style="color:#fff;">Acciones</th>                                                                   
                              </thead>
                              <tbody>
                                <?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                    <td style="display: none;"><?php echo e($persona->id); ?></td>
                                    <td><?php echo e($persona->nombre); ?></td>
                                    <td><?php echo e($persona->apellidoPaterno); ?></td>
                                    <td><?php echo e($persona->apellidoMaterno); ?></td>
                                    <td><?php echo e($persona->sexo); ?></td>
                                    <td><?php echo e($persona->edad); ?></td>
                                    <td><?php echo e($persona->direccion); ?></td>
                                    <td><?php echo e($persona->estado); ?></td>
                                    <td><?php echo e($persona->tipo); ?></td>
                                    <td>                                  
                                      <a class="btn btn-primary" href="<?php echo e(route('personal.edit',$persona->id)); ?>">Editar</a>

                                      <?php echo Form::open(['method' => 'DELETE','route' => ['personal.destroy', $persona->id],'style'=>'display:inline']); ?>

                                          <?php echo Form::submit('Borrar', ['class' => 'btn btn-danger']); ?>

                                      <?php echo Form::close(); ?>

                                    </td>
                                  </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                            </table>
                            <!-- Centramos la paginacion a la derecha -->
                          <div class="pagination justify-content-end">
                            <?php echo $personal->links(); ?>

                          </div>     
                            
                      </div>
                  </div>
              </div>
          </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel8.1\resources\views/personal/index.blade.php ENDPATH**/ ?>