<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="section-header">
      <h3 class="page__heading">Expedientes</h3>
  </div>
  <div class="section-body">
      <div class="row">
          <div class="col-lg-12">
              <div class="card">
                  <div class="card-body">                           
                      <a class="btn btn-dark" href="<?php echo e(route('expedientes.create')); ?>">Nuevo</a>        

                        <table class="table table-striped mt-2">
                          <thead style="background-color:#6777ef">                                     
                              <th style="display: none;">ID</th>
                              <th style="color:#fff;">Código Registro</th>
                              <th style="color:#fff;">Fecha Registro</th>
                              <th style="color:#fff;">Acciones</th>                                                                   
                          </thead>
                          <tbody>
                            <?php $__currentLoopData = $expedientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expediente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td style="display: none;"><?php echo e($expediente->id); ?></td>
                                <td><?php echo e($expediente->codigoRegistro); ?></td>
                                <td><?php echo e($expediente->fechaRegistro); ?></td>
                                <td>                                  
                                  <a class="btn btn-primary" href="<?php echo e(route('expedientes.edit',$expediente->id)); ?>">Editar</a>

                                  <?php echo Form::open(['method' => 'DELETE','route' => ['expedientes.destroy', $expediente->id],'style'=>'display:inline']); ?>

                                      <?php echo Form::submit('Borrar', ['class' => 'btn btn-danger']); ?>

                                  <?php echo Form::close(); ?>

                                </td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                        <!-- Centramos la paginación a la derecha -->
                      <div class="pagination justify-content-end">
                        <?php echo $expedientes->links(); ?>

                      </div>     

                  </div>
              </div>
          </div>
      </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\erp-master\resources\views/expedientes/index.blade.php ENDPATH**/ ?>