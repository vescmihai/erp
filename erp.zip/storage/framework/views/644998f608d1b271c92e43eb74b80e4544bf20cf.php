

<?php $__env->startSection('content'); ?>
    <div class="container-xl">
        <section class="section">
            <div class="section-header">
                <h3 class="page__heading">Receta Medica</h3>
            </div>
            <div class="section-body">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <a class="btn btn-dark" href="<?php echo e(route('recetamedica.create')); ?>">Nuevo</a>

                                <table class="table table-striped mt-2">
                                    <thead style="background-color:#6777ef">
                                        <th style="display: none;">ID</th>
                                        <th style=>receta</th>
                                        <th style=>medicamento</th>
                                        <th style=>cantidad</th>
                                        <th style=>dosis</th>
                                        <th style=>frecuencia</th>
                                        <th style=>Acciones</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $recetamedicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recetamedica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td style="display: none;"><?php echo e($recetamedica->id); ?></td>
                                                <?php $__currentLoopData = $recetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($receta->id == $recetamedica->idReceta): ?>
                                                        <td><?php echo e($receta->idHojadeConsulta); ?></td>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__currentLoopData = $medicamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($medicamento->id == $recetamedica->idMedicamento): ?>
                                                        <td><?php echo e($medicamento->descripcion); ?></td>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <td><?php echo e($recetamedica->catnidad); ?></td>
                                                <td><?php echo e($recetamedica->dosis); ?></td>
                                                <td><?php echo e($recetamedica->frecuencia); ?></td>
                                                <td>
                                                    <a class="btn btn-primary"
                                                        href="<?php echo e(route('recetamedica.edit', $recetamedica->id)); ?>">Editar</a>
                                                        <a class="btn btn-success"
                                                        href="<?php echo e(route('recetamedica.pdf', $recetamedica->id)); ?>">Descargar</a>
                                                    <?php echo Form::open([
                                                        'method' => 'DELETE',
                                                        'route' => ['recetamedica.destroy', $recetamedica->id],
                                                        'style' => 'display:inline',
                                                    ]); ?>

                                                    <?php echo Form::submit('Borrar', ['class' => 'btn btn-danger']); ?>

                                                    <?php echo Form::close(); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <!-- Centramos la paginacion a la derecha -->
                                <div class="pagination justify-content-end">
                                    <?php echo $recetamedicas->links(); ?>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.tabler-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\erp\resources\views/recetamedica/index.blade.php ENDPATH**/ ?>