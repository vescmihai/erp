<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Cita</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <a class="btn btn-dark" href="<?php echo e(route('cita.create')); ?>">Nuevo</a>

                            <table class="table table-striped mt-2">
                                <thead style="background-color:#6777ef">
                                    <th style="display: none;">ID</th>
                                    <th style="color:#fff;">Motivo</th>
                                    <th style="color:#fff;">Fecha</th>
                                    <th style="color:#fff;">Confirmacion</th>
                                    <th style="color:#fff;">Consulta</th>
                                    <th style="color:#fff;">Especialidad</th>
                                    <th style="color:#fff;">Doctor</th>
                                    <th style="color:#fff;">Paciente</th>
                                    <th style="color:#fff;">Acciones</th>  
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="display: none;"><?php echo e($cita->id); ?></td>
                                            <td><?php echo e($cita->motivo); ?></td>
                                            <td><?php echo e($cita->fecha); ?></td>
                                            <td><?php echo e($cita->citaConfirmada); ?></td>
                                            <?php $__currentLoopData = $consultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($consulta->id == $cita->idConsulta): ?>
                                                    <td><?php echo e($consulta->descripcion); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($especialidad->id == $cita->idEspecialidad): ?>
                                                    <td><?php echo e($especialidad->nombre); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $doctores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($doctor->id == $cita->idDoctor): ?>
                                                    <td><?php echo e($doctor->nombre); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($paciente->id == $cita->idCita): ?>
                                                    <td><?php echo e($paciente->nombre); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $personales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($personal->id == $cita->idAdministrativo): ?>
                                                <td><?php echo e($personal->nombre); ?></td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td>
                                                <a class="btn btn-primary"
                                                    href="<?php echo e(route('cita.edit', $cita->id)); ?>">Editar</a>

                                                <?php echo Form::open(['method' => 'DELETE', 'route' => ['cita.destroy', $cita->id], 'style' => 'display:inline']); ?>

                                                <?php echo Form::submit('Borrar', ['class' => 'btn btn-danger']); ?>

                                                <?php echo Form::close(); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <!-- Centramos la paginacion a la derecha -->
                            <div class="pagination justify-content-end">
                                <?php echo $citas->links(); ?>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\erp-master\resources\views/Cita/index.blade.php ENDPATH**/ ?>