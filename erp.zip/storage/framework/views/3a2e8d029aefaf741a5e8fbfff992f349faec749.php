

<?php $__env->startSection('content'); ?>
<div class="container-xl">
<section class="section">
  <div class="section-header">
      <h3 class="page__heading">Salas</h3>
  </div>
      <div class="section-body">
          <div class="row">
              <div class="col-lg-12">
                  <div class="card">
                      <div class="card-body">
                          <a class="btn btn-dark" href="<?php echo e(route('salas.create')); ?>">Nueva</a>

                            <table class="table table-striped mt-2">
                              <thead style="background-color:#6777ef">
                                  <th style="display: none;">ID</th>
                                  <th style=>Nro Sala</th>
                                  <th style=>Capacidad</th>
                                  <th style=>Tipo</th>
                                  <th style=>Sector</th>
                                  <th style=>Acciones</th>
                              </thead>
                              <tbody>
                                <?php $__currentLoopData = $salas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sala): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                    <td style="display: none;"><?php echo e($sala->id); ?></td>
                                    <td><?php echo e($sala->nroSala); ?></td>
                                    <td><?php echo e($sala->capacidad); ?></td>
                                    <td><?php echo e($sala->tipo); ?></td>
                                    <?php $__currentLoopData = $sectores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($sector->id == $sala->idSector): ?>
                                            <td><?php echo e($sector->descripcion); ?></td>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <td>
                                      <a class="btn btn-primary" href="<?php echo e(route('salas.edit', $sala->id)); ?>">Editar</a>

                                      <?php echo Form::open(['method' => 'DELETE','route' => ['salas.destroy', $sala->id],'style'=>'display:inline']); ?>

                                          <?php echo Form::submit('Borrar', ['class' => 'btn btn-danger']); ?>

                                      <?php echo Form::close(); ?>

                                    </td>
                                  </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                            </table>
                            <!-- Centramos la paginacion a la derecha -->
                          <div class="pagination justify-content-end">
                            <?php echo $salas->links(); ?>

                          </div>

                      </div>
                  </div>
              </div>
          </div>
      </div>
    </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.tabler-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\erp\resources\views/salas/index.blade.php ENDPATH**/ ?>